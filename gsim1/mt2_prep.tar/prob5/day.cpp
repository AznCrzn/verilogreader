#include<iostream>
#include<iomanip>
#include<cmath>
#include<string>
#include<stdio.h>
#include"day.h"


Day::Day() : day_number(0)
{
  day_number=0;
}// default constructor

Day::Day(string dn) 
{
  day_number = name_to_num(dn);
} // constructor with day name

Day::Day(int dno) : day_number(dno-1) 
{

}// constructor with day number


string Day::get_yesterday(){
  int yno;
  if (day_number==0){
    yno=6;
  }// end if
  else{
    yno=(day_number-1);
  }//end else
  return num_to_name(yno);

}// end yesterday

string Day::get_tomorrow(){
  int tno;
  if (day_number==6){
    tno=0;
  }//end if
  else{
    tno=(day_number+1);
  }//end else
  return num_to_name(tno);
}// end tomorrow

Day Day::operator+(int increment){

  int day_index=day_number, new_index;
  if(increment < 0){
    // convert negative increment to appropritate index
    increment = 7 - (-increment % 7);
  }

  if((day_index+increment)>6){
    new_index=(day_index+increment)%7;
  }//end if
  else{
    new_index=day_index+increment;
  }//end else
  Day Incday(new_index+1);  // + 1 just to account for Constructor 
                            //  wanting 1 based index
  return Incday;
}// end operator+

Day Day::operator-(int decrement){

  return operator+(-decrement);
}// end operator-


ostream& operator<<(ostream& osObject, const Day& myday) 
{
  osObject<<endl<<"Day is : "<<myday.get_day_name()<<", day number : "<<myday.day_number+1<<endl;
  return osObject;
}// end friend function

string Day::num_to_name(int num) const
{
  string daysofweek[7]={"monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
  return daysofweek[num];
}

int Day::name_to_num(string name) const
{
  string daysofweek[7]={"monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
  for(int i=0; i < 7; i++){
    if(name == daysofweek[i]){
      return i;
    }
  }
}
