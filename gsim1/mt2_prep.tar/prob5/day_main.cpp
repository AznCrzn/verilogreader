#include<iostream>
#include"day.h"
#include<string>


using namespace std;


int main(){

 Day birthday,Thanksgiving("thursday");

 cout<<birthday<<endl<<Thanksgiving<<endl;
 
 Day Longweekendstarts=Thanksgiving+1;
 Day Aweeklater=Thanksgiving+8;
 Day Aweekbefore=Thanksgiving-7;
 string Yday=Thanksgiving.get_yesterday();
 string Tday=Thanksgiving.get_tomorrow();
 cout<<"Long weekend starts: "<<Longweekendstarts<<endl;
 cout<<"About a week later: "<<Aweeklater<<endl;
 cout<<"A week before: "<<Aweekbefore<<endl;
 cout<<"Yesterday was: "<<Yday<<endl;
 cout<<"Tomorrow is: "<<Tday<<endl;


return 0;
}//end main
