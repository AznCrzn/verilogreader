#ifndef DAY_H
#define DAY_H
#include<iostream>
#include<string>
using namespace std;



class Day{

  int day_number;

  string num_to_name(int) const;
  int name_to_num(string) const ;

 public:

  Day();// default constructor
  Day(string); //constructor with day name
  Day(int); // constructor with day number

  string get_day_name() const { return num_to_name(day_number); }// returns the day name
  int get_day_number() const {return day_number; } // returns the day number
  string get_yesterday(); // returns yesterday
  string get_tomorrow(); // returns tomorrow
  Day operator+(int); // prototype of increment operator 
  Day operator-(int); // prototype of decrement operator

  friend ostream& operator<<(ostream&, const Day&); // to print the Day to screen

};//end class definition

#endif
