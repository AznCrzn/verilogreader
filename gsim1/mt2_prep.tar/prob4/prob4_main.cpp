#include<iostream>
#include<vector>
#include<iomanip>

using namespace std;

void swap(vector<int>&, int,int); // prototype for swap function

int main()
{
  vector<int> x;
  int done=0, m,n;
  cout<<endl<<" Enter an integer list ending with -1 : "<<endl;
  
  cin>>done;
  while(done!=-1){
    x.push_back(done);
    cin>>done;
  } //end while
  
  cout<<endl<<" The list you entered was :"<<endl;
  for (int i=0;i<x.size();i++){
    cout<<x[i]<< " ";
  }// end for
  cout << endl;
  cout <<" Enter the index of two intgers you wish to swap in the list : "<<endl;
  cin>>m>>n;
  
  swap(x,m,n);
  cout << " The list after the swap operation is :"<<endl;
  for (int i=0;i<x.size();i++){
    cout<<x[i]<<" ";
  }// end for
  cout<<endl;
  return 0;
}//end main

void swap(vector<int>&y, int a, int b){
  int temp=y[a];
  y[a]=y[b];
  y[b]=temp;
  
} // end swap
