#include<iostream>
#include"day.h"
#include"businessday.h"
#include<string>


using namespace std;


int main(){

 Businessday firstday,Payday("friday");

 cout<<firstday<<endl<<Payday<<endl;
 
 Businessday StartofWeek=Payday+1;
 Businessday Aweeklater=Payday+5;
 Businessday Aweekbefore=Payday-5;
 string Yday=Payday.get_yesterday();
 string Tday=Payday.get_tomorrow();
 cout<<"Start of Work Week is: "<<StartofWeek<<endl;
 cout<<"About a week later: "<<Aweeklater<<endl;
 cout<<"A week before: "<<Aweekbefore<<endl;
 cout<<"Yesterday was: "<<Yday<<endl;
 cout<<"Tomorrow is: "<<Tday<<endl;


return 0;
}//end main
