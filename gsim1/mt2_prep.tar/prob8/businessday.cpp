#include<iostream>
#include<iomanip>
#include<cmath>
#include<string>
#include<stdio.h>
#include"day.h"
#include"businessday.h"


Businessday::Businessday() : Day() {

}// default constructor

Businessday::Businessday(string dn) : Day(dn) 
{

} // constructor with businessday name

Businessday::Businessday(int dno) : Day(1+((dno - 1) % 5)) 
{

}// constructor with businessday number


string Businessday::get_yesterday(){
  int yno;
  if (day_number==0){
    yno=4;
  }// end if
  else{
    yno=(day_number-1);
  }//end else
  return num_to_name(yno);
}// end yesterday

string Businessday::get_tomorrow(){
  int yno;
  if (day_number==4){
    yno=0;
  }// end if
  else{
    yno=(day_number+1);
  }//end else
  return num_to_name(yno);
}// end tomorrow

Businessday Businessday::operator+(int increment){
  int day_index=day_number, new_index;
  if(increment < 0){
    // convert negative increment to appropritate index
    increment = 5 - (-increment % 5);
  }

  if((day_index+increment)>4){
    new_index=(day_index+increment)%5;
  }//end if
  else{
    new_index=day_index+increment;
  }//end else
  Businessday Incday(new_index+1); // + 1 just to account for Constructor 
                                   //  wanting 1 based index
  return Incday;
}// end operator+

Businessday Businessday::operator-(int decrement){
  return operator+(-decrement);
}

