#ifndef BUSINESSDAY_H
#define BUSINESSDAY_H
#include"day.h"


class Businessday:public Day {


 public:

  Businessday();// default constructor
  Businessday(string); //constructor with day name
  Businessday(int); // constructor with day number

  string get_yesterday(); // returns yesterday
  string get_tomorrow(); // returns tomorrow
  Businessday operator+(int); // prototype of increment operator 
  Businessday operator-(int); // prototype of decrement operator

};//end class definition

#endif
