#include<iostream>
#include<fstream>
#include"day.h"
#include<string>
#include<iomanip>
#include<map>


using namespace std;


int main(int argc, char*argv[]){
  if(argc!=2){
    cout<<"Usage: ./test in_filename"<<endl;
    return -1;
  }
  else{

    ifstream inputfile;
    inputfile.open(argv[1]);
    map<string,int> daycountmap;

    if(!inputfile.good()){
      cout<<"Unable to open file "<<argv[1]<<endl;
      return -1;
    }
    else{ // file opened properly
			
      string day_str;
      
      while(!inputfile.eof()){
	inputfile>>day_str;
	if(inputfile.fail()){
	  continue;
	}
	map<string, int>::iterator it = daycountmap.find(day_str);
	if(it == daycountmap.end()){
	  daycountmap[day_str] = 1;
	}
	else {
	  daycountmap[day_str]++;
	}
      }//end while
      string choice;
      cout<<"Enter a day to find out occurance / Enter 'all' to see for all days :";
      cin>>choice;
      if(choice=="all"){
	cout<<endl<<"Occurance of days"<<endl;
	for(map<string, int>::iterator it=daycountmap.begin();it !=daycountmap.end();it++){
	  cout<<it->first<<":"<<it->second<<endl;
	}//end for
      }//end if
      else{
	cout<<"Number of occurences of "<<choice<<" : "<<daycountmap[choice]<<endl;
      }//end else	
    }//end else file opened properly
  }//end else
  return 0;
}//end main
